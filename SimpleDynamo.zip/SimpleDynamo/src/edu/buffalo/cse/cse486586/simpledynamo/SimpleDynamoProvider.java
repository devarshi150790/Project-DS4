package edu.buffalo.cse.cse486586.simpledynamo;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;

import android.R.integer;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.SystemClock;
import android.telephony.TelephonyManager;
import android.util.Log;

public class SimpleDynamoProvider extends ContentProvider {

	public String key;
	public String value;
	public boolean flag = false;
	public String portStr="";
	public String succ="";
	public String pred="";
	public int count=0;
	public String ip="10.0.2.2";
	public MatrixCursor mcursor=null;
	public String toWrite=null;
	public int ver=0;
	public int version=0;
	long currtime=0;
	long endtime=0;
	public boolean ack=false;
	public int failedPort=0;
	public String files[];
	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// TODO Auto-generated method stub

		checkPort(portStr);
		int replicate_port1= 0, replicate_port2=0;

		key=values.get("key").toString();
		value=values.get("value").toString();
		try
		{
			if(portStr.equals("5554"))
			{

				flag=returnVal(key, "5556", portStr);
				
				if(flag)
				{
					replicate_port1=11112;
					replicate_port2=11116;
					Log.v("AssignVal:Key:Val:PortStr:Rep1:Rep2",key+":"+value+":"+portStr+":"+replicate_port1+":"+replicate_port2);
					assignVal(key, value, getPortNo(portStr), replicate_port1, replicate_port2);

				}

				else if(!flag)
				{
					flag=returnVal(key, portStr,"5558");

					if(flag)
					{
						replicate_port1=11108;
						replicate_port2=11112;
						Log.v("AssignVal:Key:Val:PortStr:Rep1:Rep2",key+":"+value+":"+"5558"+":"+replicate_port1+":"+replicate_port2);
						assignVal(key, value, getPortNo("5558"), replicate_port1, replicate_port2);

					}

					else if(!flag)
					{
						replicate_port1=11108;
						replicate_port2=11116;
						Log.v("AssignVal:Key:Val:PortStr:Rep1:Rep2",key+":"+value+":"+"5556"+":"+replicate_port1+":"+replicate_port2);
						//flag=returnVal(key, "5558", "5556");
						assignVal(key, value, getPortNo("5556"), replicate_port1, replicate_port2);

					}
				}
			}				

			else if(portStr.equals("5556"))
			{
				flag=returnVal(key, "5558", portStr);

				if(flag)
				{
					replicate_port1=11108;
					replicate_port2=11116;
					Log.v("AssignVal:Key:Val:PortStr:Rep1:Rep2",key+":"+value+":"+portStr+":"+replicate_port1+":"+replicate_port2);
					assignVal(key, value, getPortNo(portStr), replicate_port1, replicate_port2);

				}

				else if(!flag)
				{
					flag=returnVal(key, portStr, "5554");

					if(flag)
					{
						replicate_port1=11112;
						replicate_port2=11116;
						Log.v("AssignVal:Key:Val:PortStr:Rep1:Rep2",key+":"+value+":"+"5554"+":"+replicate_port1+":"+replicate_port2);
						assignVal(key, value, getPortNo("5554"), replicate_port1, replicate_port2);

					}

					else if (!flag)
					{
						replicate_port1=11108;
						replicate_port2=11112;
						Log.v("AssignVal:Key:Val:PortStr:Rep1:Rep2",key+":"+value+":"+"5558"+":"+replicate_port1+":"+replicate_port2);
						//flag=returnVal(key, "5554", "5558");
						assignVal(key, value, getPortNo("5558"), replicate_port1, replicate_port2);

					}
				}
			}				

			else if(portStr.equals("5558"))
			{
				flag=returnVal(key, "5554", portStr);

				if(flag)
				{
					replicate_port1=11108;
					replicate_port2=11112;
					Log.v("AssignVal:Key:Val:PortStr:Rep1:Rep2",key+":"+value+":"+portStr+":"+replicate_port1+":"+replicate_port2);
					assignVal(key, value, getPortNo(portStr), replicate_port1, replicate_port2);

				}

				else if(!flag)
				{
					flag=returnVal(key, portStr, "5556" );

					if(flag)
					{
						replicate_port1=11108;
						replicate_port2=11116;
						Log.v("AssignVal:Key:Val:PortStr:Rep1:Rep2",key+":"+value+":"+"5556"+":"+replicate_port1+":"+replicate_port2);
						assignVal(key, value, getPortNo("5556"), replicate_port1, replicate_port2);
					}

					else if(!flag)
					{

						//flag=returnVal(key, "5556", "5554");
						replicate_port1=11112;
						replicate_port2=11116;
						Log.v("AssignVal:Key:Val:PortStr:Rep1:Rep2",key+":"+value+":"+"5554"+":"+replicate_port1+":"+replicate_port2);
						assignVal(key, value, getPortNo("5554"), replicate_port1, replicate_port2);

					}
				}
			}				


		}
		catch (Exception e) {
			// TODO: handle exception
		}

		return null;
	}

	private void assignVal(String key, String value, int portNo, int replicate_port1, int replicate_port2) {
		try{
			Log.v("Port No is", ""+portNo);
			toWrite=value;
			Socket cSocket1 = new Socket(InetAddress.getByName(ip),portNo);
			DataOutputStream d1=new DataOutputStream(cSocket1.getOutputStream());
			endtime=System.currentTimeMillis()+200;
			d1.writeBytes("KeyVal:"+key+":"+toWrite+":"+getPortNo(portStr));
			d1.flush();
			d1.close();
			cSocket1.close();

			if(Integer.parseInt(key)==0)
				ver++;

			while(!ack && endtime>System.currentTimeMillis())
			{

			}
			if(!ack)
			{
				failedPort=portNo;
				Log.v("falied port",Integer.toString(portNo));
			}
			ack=false;

			Socket cSocket1_replicate = new Socket(InetAddress.getByName(ip),replicate_port1);
			DataOutputStream d1_replicate=new DataOutputStream(cSocket1_replicate.getOutputStream());
			d1_replicate.writeBytes("Replica : "+key+":"+toWrite+":"+ver+":"+portNo);
			d1_replicate.close();
			cSocket1_replicate.close();

			Socket cSocket2_replicate = new Socket(InetAddress.getByName(ip),replicate_port2);
			DataOutputStream d2_replicate=new DataOutputStream(cSocket2_replicate.getOutputStream());
			d2_replicate.writeBytes("Replica : "+key+":"+toWrite+":"+ver+":"+portNo);
			d2_replicate.close();
			cSocket2_replicate.close();

		}
		catch (Exception e) {
			// TODO: handle exception
			Log.v("Exception e ", e.toString());
		}

		// TODO Auto-generated method stub

	}


	@Override
	public boolean onCreate() {
		// TODO Auto-generated method stub

		TelephonyManager tel = (TelephonyManager) this.getContext().getSystemService(Context.TELEPHONY_SERVICE);
		portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
		ServerTask s = new ServerTask();
		s.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

		ClientTask cT = new ClientTask();
		cT.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR);
		String files[]=this.getContext().fileList();

		for(int i=0;i<files.length;i++)
			this.getContext().deleteFile(files[i]);

		return false;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		// TODO Auto-generated method stub
		if(selection.equals("LDump"))
		{
			FileInputStream fis;
			files=this.getContext().fileList();
			Log.v("File Size", Integer.toString(files.length));
			MatrixCursor mcursor=new MatrixCursor(new String[]{"key","value"});
			mcursor.addRow(new String[]{"version", Integer.toString(ver)});
			for(int i=0;i<files.length;i++)
			{
				try {
					fis = this.getContext().openFileInput(files[i]);
					BufferedReader br = new BufferedReader(new InputStreamReader(fis));
					String value = br.readLine();
					mcursor.addRow(new String[]{files[i],value});
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	

			}
			return (Cursor)mcursor;
		}

		if(selection.equals("Get"))
		{		
			FileInputStream fis;
			files=this.getContext().fileList();
			flag=false;
			MatrixCursor mcursor=new MatrixCursor(new String[]{"key","value"});
			mcursor.addRow(new String[]{"version", Integer.toString(ver)});
			for(int i=0;i<files.length;i++)
			{
				try {
					fis = this.getContext().openFileInput(files[i]);
					BufferedReader br = new BufferedReader(new InputStreamReader(fis));
					String value = br.readLine();
					mcursor.addRow(new String[]{files[i],value});
				} 
				catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
			}
			return (Cursor)mcursor;
		}	
		return null;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean returnVal(String key, String pred, String portStr)
	{
		try {
			if(genHash(pred).compareTo(genHash(portStr))>=0 &&
					(genHash(key).compareTo(genHash(pred))>0||genHash(key).compareTo(genHash(portStr))<=0))
				return true;
			else if(genHash(key).compareTo(genHash(portStr))<=0 && genHash(key).compareTo(genHash(pred))>0)
				return true;

		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}


	private String genHash(String input) throws NoSuchAlgorithmException {
		MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
		byte[] sha1Hash = sha1.digest(input.getBytes());
		Formatter formatter = new Formatter();
		for (byte b : sha1Hash) {
			formatter.format("%02x", b);
		}
		return formatter.toString();
	}

	public Uri buildUri(String scheme, String authority) {
		Uri.Builder uriBuilder = new Uri.Builder();
		uriBuilder.authority(authority);
		uriBuilder.scheme(scheme);
		return uriBuilder.build();
	}

	public int getPortNo(String portStr)
	{
		if(portStr.equals("5554"))
			return 11108;

		else if(portStr.equals("5556"))
			return 11112;

		else
			return 11116;
	}

	public void checkPort(String portStr)
	{
		if(portStr.equals("5554"))
			{
			pred="5556";
			succ="5558";
			
			}

		else if(portStr.equals("5556"))
		{
			pred="5558";
			succ="5554";
			
		}

		else
		{
			pred="5554";
			succ="5556";
		}
	}

	
	public class ServerTask extends AsyncTask<Void, String, Void>{

		@Override
		protected Void doInBackground(Void... params) {

			try {
				ServerSocket serverSocket = new ServerSocket(10000);
				while(true)
				{
					Socket clientSocket = serverSocket.accept();

					BufferedReader br=new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

					String inputline=br.readLine();

					if(inputline.contains("Recovery"))
					{
						String verStr = inputline.split("\\|")[1];
						ver = Integer.parseInt(verStr);
						String kV = inputline.split("\\|")[2];
						String keyValue[] = kV.split(";");
						for(int i=0;i<keyValue.length;i++)
						{
							String key = keyValue[i].split(":")[0];
							String value = keyValue[i].split(":")[1];
							FileOutputStream fos = getContext().openFileOutput(key, Context.MODE_WORLD_READABLE);
							fos.write(value.getBytes());
							fos.close();
						}
					}


					if(inputline.contains("KeyVal"))
					{
						String key1=inputline.split(":")[1];
						String val1=inputline.split(":")[2];
						int pNo=Integer.parseInt(inputline.split(":")[3]);

						FileOutputStream fos;
						fos = getContext().openFileOutput(key1, Context.MODE_WORLD_READABLE);
						fos.write((val1).getBytes());
						fos.close();
						Socket cSocket1_reply = new Socket(InetAddress.getByName(ip), pNo);
						DataOutputStream d1=new DataOutputStream(cSocket1_reply.getOutputStream());
						d1.writeBytes("Ack");
						d1.close();
						cSocket1_reply.close();
					}

					else if(inputline.contains("Replica"))
					{
						String key1=inputline.split(":")[1];
						String val1=inputline.split(":")[2];
						version=Integer.parseInt(inputline.split(":")[3]);
						if(version>ver)
						{
							ver=version;
						}
						FileOutputStream fos;

						fos = getContext().openFileOutput(key1, Context.MODE_WORLD_READABLE);
						fos.write((val1).getBytes());
						fos.close();

						Log.v("writeRelpica", "wrote Replica "+val1);
					}	

					if(inputline.contains("Ack"))
					{
						ack=true;
					}

					int f=0;
					if(portStr.equals("5554"))
					{
						if(inputline.contains("I"))			
						{
							int newFailNodeVer=Integer.parseInt(inputline.split(":")[2]);

							if(newFailNodeVer<ver)
							{
								count=1;
							}
							count++;
							if(count==1)
							{
								Log.v("Count 5554", Integer.toString(count));
								String genHashValueMsg = genHash(inputline.split(":")[1]);
								if(genHashValueMsg.compareTo(genHash("5554")) < 0){
									pred = inputline.split(":")[1];
									f=1;
								}else if(genHashValueMsg.compareTo(genHash("5554")) > 0){
									succ = inputline.split(":")[1];
									f=2;
								}

								if(inputline.split(":")[0].equals("5556"))
									clientSocket = new Socket(InetAddress.getByName(ip),11112);
								else if(inputline.split(":")[0].equals("5558"))
									clientSocket = new Socket(InetAddress.getByName(ip),11116);

								DataOutputStream dos=new DataOutputStream(clientSocket.getOutputStream());

								if(f==1)
									dos.writeBytes("succ:5554:"+count);
								else if(f==2)
									dos.writeBytes("pred:5554:"+count);
								dos.close();
								clientSocket.close();

							}
							else if(count==2)
							{
								Log.v("Count 2 5554", Integer.toString(count));
								String genHashValueMsg = genHash(inputline.split(":")[1]);

								if(genHashValueMsg.compareTo(genHash("5554")) < 0){
									pred = inputline.split(":")[1];
									succ="5558";
								}else if(genHashValueMsg.compareTo(genHash("5554")) > 0){
									succ = inputline.split(":")[1];
									pred="5556";
								}

								Socket cSocket1 = new Socket(InetAddress.getByName(ip),11112);
								DataOutputStream d1=new DataOutputStream(cSocket1.getOutputStream());
								d1.writeBytes("succ:5554:"+count+":5558");
								d1.close();
								cSocket1.close();

								Socket cSocket2 = new Socket(InetAddress.getByName(ip),11116);
								DataOutputStream d2=new DataOutputStream(cSocket2.getOutputStream());
								d2.writeBytes("pred:5554:"+count+":5556");
								d2.close();
								cSocket2.close();
							}

							if(newFailNodeVer < ver)
							{
								String rec = ver+"|";
								String fileList[]=getContext().fileList();
								for(int i=0;i<fileList.length;i++)
								{
									FileInputStream fis = getContext().openFileInput(fileList[i]);	
									br = new BufferedReader(new InputStreamReader(fis));
									String value = br.readLine();
									rec+=fileList[i]+":"+value+";";
									fis.close();
								}
								int recPort=getPortNo(inputline.split(":")[1]);
								try{
									Socket revClient = new Socket(InetAddress.getByName(ip),recPort);
									DataOutputStream dos=new DataOutputStream(revClient.getOutputStream());
									dos.writeBytes("Recovery|"+rec);
									dos.close();
									revClient.close();
								}
								catch(UnknownHostException e)
								{
									e.printStackTrace();
								}catch(IOException e)
								{
									e.printStackTrace();
								}	
								
							}

							if(inputline.contains("succ")||inputline.contains("pred"))
							{
								if(inputline.contains("succ"))
								{
									succ=inputline.split(":")[1];
								}

								else if(inputline.contains("pred"))
								{
									pred=inputline.split(":")[1];
								}
								count = Integer.parseInt(inputline.split(":")[2]);

								if(count==2)
								{
									pred=inputline.split(":")[3];
								}
								
							}

						}

					}

					if(portStr.equals("5556"))
					{

						
						if(inputline.contains("I"))			
						{
							int newFailNodeVer=Integer.parseInt(inputline.split(":")[2]);

							if(newFailNodeVer<ver)
							{
								count=1;
							}
							count++;

							if(count==1)
							{
								String genHashValueMsg = genHash(inputline.split(":")[1]);
								if(genHashValueMsg.compareTo(genHash("5556")) < 0){
									pred = inputline.split(":")[1];
									f=1;
								}else if(genHashValueMsg.compareTo(genHash("5556")) > 0){
									succ = inputline.split(":")[1];
									f=2;
								}

								if(inputline.split(":")[0].equals("5554"))
									clientSocket = new Socket(InetAddress.getByName(ip),11108);
								else if(inputline.split(":")[0].equals("5558"))
									clientSocket = new Socket(InetAddress.getByName(ip),11116);

								DataOutputStream dos=new DataOutputStream(clientSocket.getOutputStream());

								if(f==1)
									dos.writeBytes("succ:5556:"+count);
								else if(f==2)
									dos.writeBytes("pred:5556:"+count);
								dos.close();
								clientSocket.close();

							}
							else if(count==2)
							{
								String genHashValueMsg = genHash(inputline.split(":")[1]);

								if(genHashValueMsg.compareTo(genHash("5556")) < 0){
									pred = inputline.split(":")[1];
									succ="5554";
								}else if(genHashValueMsg.compareTo(genHash("5556")) > 0){
									succ = inputline.split(":")[1];
									pred="5558";
								}

								Socket cSocket1 = new Socket(InetAddress.getByName(ip),11108);
								DataOutputStream d1=new DataOutputStream(cSocket1.getOutputStream());
								d1.writeBytes("succ:5558:"+count+":5556");
								d1.close();
								cSocket1.close();

								Socket cSocket2 = new Socket(InetAddress.getByName(ip),11116);
								DataOutputStream d2=new DataOutputStream(cSocket2.getOutputStream());
								d2.writeBytes("pred:5554:"+count+":5556");
								d2.close();
								cSocket2.close();
							}


							if(newFailNodeVer < ver)
							{
								String rec = ver+"|";
								String fileList[]=getContext().fileList();
								for(int i=0;i<fileList.length;i++)
								{
									FileInputStream fis = getContext().openFileInput(fileList[i]);	
									br = new BufferedReader(new InputStreamReader(fis));
									String value = br.readLine();
									rec+=fileList[i]+":"+value+";";
									fis.close();
								}
								int recoverPort=getPortNo(inputline.split(":")[1]);
								try{
									Socket revClient = new Socket(InetAddress.getByName(ip),recoverPort);
									DataOutputStream dos=new DataOutputStream(revClient.getOutputStream());
									dos.writeBytes("Recovery|"+rec);
									dos.close();
									revClient.close();
								}
								catch(UnknownHostException e)
								{
									e.printStackTrace();
								}catch(IOException e)
								{
									e.printStackTrace();
								}	
							}


							if(inputline.contains("succ")||inputline.contains("pred"))
							{
								if(inputline.contains("succ"))
								{
									succ=inputline.split(":")[1];
								}

								else if(inputline.contains("pred"))
								{
									pred=inputline.split(":")[1];
								}
								count = Integer.parseInt(inputline.split(":")[2]);

								if(count==2)
								{
									pred=inputline.split(":")[3];
								}
								
							}
						}
					}
					else if(portStr.equals("5558"))
					{
						if(inputline.contains("succ")||inputline.contains("pred")) 
						{
							if(inputline.contains("succ")){
								succ=inputline.split(":")[1];

							}

							else if(inputline.contains("pred"))
							{
								pred=inputline.split(":")[1];
							}
							count = Integer.parseInt(inputline.split(":")[2]);

							if(count==2)
							{
								succ=inputline.split(":")[3];
							}
						}

					}


				}

			}
			catch (Exception e) {
				// TODO: handle exception
			}
			return null;

		}
	}


	public class ClientTask extends AsyncTask<Void, String, Void>{

		Socket clientSocket=null;
		@Override
		protected Void doInBackground(Void... params) {
			try{

				if(portStr.equals("5556"))
				{
					clientSocket = new Socket(InetAddress.getByName(ip),11108);
					DataOutputStream dos=new DataOutputStream(clientSocket.getOutputStream());
					dos.writeBytes("I am:5556:"+0);
					dos.close();
					clientSocket.close();
					
				}
				else if(portStr.equals("5558"))
				{
					clientSocket = new Socket(InetAddress.getByName(ip),11108);
					DataOutputStream dos=new DataOutputStream(clientSocket.getOutputStream());
					dos.writeBytes("I am:5558:"+0);
					dos.close();
					clientSocket.close();
				}
				else if(portStr.equals("5554"))
				{
					clientSocket = new Socket(InetAddress.getByName(ip),11112);
					DataOutputStream dos=new DataOutputStream(clientSocket.getOutputStream());
					dos.writeBytes("I am:5554:"+0);
					dos.close();
					clientSocket.close();
				}


			}
			catch (Exception e) {
			}
			return null;
		}    	
	}

}
