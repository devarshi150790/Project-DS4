package edu.buffalo.cse.cse486586.simpledynamo;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.database.Cursor;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class SimpleDynamoActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_simple_dynamo);
    
		final TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());
        
        findViewById(R.id.button1).setOnClickListener(new OnTestClickListener(tv, getContentResolver(), "Put1"));
        findViewById(R.id.button2).setOnClickListener(new OnTestClickListener(tv, getContentResolver(), "Put2"));
        findViewById(R.id.button3).setOnClickListener(new OnTestClickListener(tv, getContentResolver(), "Put3"));
	
        findViewById(R.id.button4).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Uri uri=buildUri("content", "edu.buffalo.cse.cse486586.simpledynamo.provider");
				Cursor c = getContentResolver().query(uri,null, "LDump", null, null);
				c.moveToFirst();
				String version=c.getString(c.getColumnIndex("value"));
				c.moveToNext();
				String key="";
				for(int i=0; i<c.getCount()-1; i++){
					key="";
					key+= "key: ";
					key += c.getString(c.getColumnIndex("key"));
					key+= " value: ";
					key+= c.getString(c.getColumnIndex("value"));
					key += "\n";
					tv.append(key);
					c.moveToNext();
				}
				tv.append("Ldump total values:"+(c.getCount()-1));
			}
		});
        
        
        findViewById(R.id.button5).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Uri uri=buildUri("content", "edu.buffalo.cse.cse486586.simpledynamo.provider");
				Cursor c = getContentResolver().query(uri,null, "Get", null, null);
				c.moveToFirst();
				String version=c.getString(c.getColumnIndex("value"));
				c.moveToNext();
				String key="";
				for(int i=0; i<c.getCount()-1; i++){
					key="";
					key+= "key: ";
					key += c.getString(c.getColumnIndex("key"));
					key+= " value: ";
					key+= c.getString(c.getColumnIndex("value"));
					key += "\n";
					tv.append(key);
					c.moveToNext();
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				tv.append("Get total values:"+(c.getCount()-1));
			}
		});
		
		
	}

	private Uri buildUri(String scheme, String authority) {
		Uri.Builder uriBuilder = new Uri.Builder();
		uriBuilder.authority(authority);
		uriBuilder.scheme(scheme);
		return uriBuilder.build();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.simple_dynamo, menu);
		return true;
	}

}
